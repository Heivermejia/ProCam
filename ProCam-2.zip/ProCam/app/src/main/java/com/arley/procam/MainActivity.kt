package com.arley.procam

import android.Manifest
import android.content.ContentValues
import android.content.pm.PackageManager
import android.hardware.camera2.CameraCharacteristics
import android.hardware.camera2.CaptureRequest
import android.os.Bundle
import android.provider.MediaStore
import android.view.MotionEvent
import android.view.View
import android.widget.Button
import android.widget.SeekBar
import android.widget.TextView
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.camera.camera2.interop.Camera2CameraInfo
import androidx.camera.camera2.interop.Camera2Interop
import androidx.camera.camera2.interop.ExperimentalCamera2Interop
import androidx.camera.core.*
import androidx.camera.extensions.ExtensionMode
import androidx.camera.extensions.ExtensionsManager
import androidx.camera.lifecycle.ProcessCameraProvider
import androidx.camera.view.PreviewView
import androidx.core.content.ContextCompat
import java.text.SimpleDateFormat
import java.util.Locale

@OptIn(ExperimentalCamera2Interop::class)
class MainActivity : AppCompatActivity() {

    private lateinit var preview: PreviewView
    private lateinit var btnMode: Button
    private lateinit var btnRaw: Button
    private lateinit var btnManual: Button
    private lateinit var tvInfo: TextView
    private lateinit var evSeek: SeekBar
    private lateinit var isoSeek: SeekBar
    private lateinit var shSeek: SeekBar
    private lateinit var manualBox: View

    private var provider: ProcessCameraProvider? = null
    private var ext: ExtensionsManager? = null
    private var capture: ImageCapture? = null
    private var camera: Camera? = null
    private var modes = listOf(ExtensionMode.NONE)
    private var idx = 0
    private var raw = false
    private var manual = false
    private var evLower = 0
    private var isoMin = 100
    private var isoMax = 3200
    private val shutters = listOf(1000, 500, 250, 125, 60, 30, 15, 8, 4, 2) // 1/x s

    private val names = mapOf(
        ExtensionMode.NONE to "Normal", ExtensionMode.HDR to "HDR",
        ExtensionMode.NIGHT to "Noche", ExtensionMode.AUTO to "Auto",
        ExtensionMode.FACE_RETOUCH to "Retoque", ExtensionMode.BOKEH to "Retrato"
    )

    private val askPerm = registerForActivityResult(
        ActivityResultContracts.RequestPermission()
    ) { ok -> if (ok) start() else finish() }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        preview = findViewById(R.id.preview)
        btnMode = findViewById(R.id.btnMode)
        btnRaw = findViewById(R.id.btnRaw)
        btnManual = findViewById(R.id.btnManual)
        tvInfo = findViewById(R.id.tvInfo)
        evSeek = findViewById(R.id.evSeek)
        isoSeek = findViewById(R.id.isoSeek)
        shSeek = findViewById(R.id.shSeek)
        manualBox = findViewById(R.id.manualBox)
        isoSeek.progress = 4
        shSeek.progress = 4

        findViewById<Button>(R.id.btnShutter).setOnClickListener { shoot() }
        btnMode.setOnClickListener { idx = (idx + 1) % modes.size; bind() }
        btnRaw.setOnClickListener { raw = !raw; bind() }
        btnManual.setOnClickListener { manual = !manual; bind() }

        evSeek.setOnSeekBarChangeListener(seekListener(
            onChange = { camera?.cameraControl?.setExposureCompensationIndex(evLower + it) },
            onDone = {}
        ))
        isoSeek.setOnSeekBarChangeListener(seekListener(
            onChange = { updateInfo() }, onDone = { bind() }))
        shSeek.setOnSeekBarChangeListener(seekListener(
            onChange = { updateInfo() }, onDone = { bind() }))

        preview.setOnTouchListener { v, e ->
            if (e.action == MotionEvent.ACTION_UP) {
                val p = preview.meteringPointFactory.createPoint(e.x, e.y)
                camera?.cameraControl?.startFocusAndMetering(FocusMeteringAction.Builder(p).build())
                v.performClick()
            }
            true
        }
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.CAMERA)
            == PackageManager.PERMISSION_GRANTED) start()
        else askPerm.launch(Manifest.permission.CAMERA)
    }

    private fun seekListener(onChange: (Int) -> Unit, onDone: () -> Unit) =
        object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(s: SeekBar?, p: Int, fromUser: Boolean) {
                if (fromUser) onChange(p)
            }
            override fun onStartTrackingTouch(s: SeekBar?) {}
            override fun onStopTrackingTouch(s: SeekBar?) = onDone()
        }

    private fun start() {
        val f = ProcessCameraProvider.getInstance(this)
        f.addListener({
            provider = f.get()
            val ef = ExtensionsManager.getInstanceAsync(this, provider!!)
            ef.addListener({
                ext = ef.get()
                val base = CameraSelector.DEFAULT_BACK_CAMERA
                modes = listOf(
                    ExtensionMode.NONE, ExtensionMode.HDR, ExtensionMode.NIGHT,
                    ExtensionMode.AUTO, ExtensionMode.FACE_RETOUCH, ExtensionMode.BOKEH
                ).filter { it == ExtensionMode.NONE || ext!!.isExtensionAvailable(base, it) }
                bind()
            }, ContextCompat.getMainExecutor(this))
        }, ContextCompat.getMainExecutor(this))
    }

    private fun <T> manualOpts(e: Camera2Interop.Extender<T>) {
        e.setCaptureRequestOption(CaptureRequest.CONTROL_AE_MODE, CaptureRequest.CONTROL_AE_MODE_OFF)
        e.setCaptureRequestOption(CaptureRequest.SENSOR_SENSITIVITY, currentIso())
        e.setCaptureRequestOption(CaptureRequest.SENSOR_EXPOSURE_TIME, currentShutterNs())
    }

    private fun currentIso() = (100 + isoSeek.progress * 100).coerceIn(isoMin, isoMax)
    private fun currentShutterNs() = 1_000_000_000L / shutters[shSeek.progress]

    private fun bind() {
        val p = provider ?: return
        val base = CameraSelector.DEFAULT_BACK_CAMERA
        val mode = modes[idx]
        val plain = mode == ExtensionMode.NONE // RAW y manual solo en modo Normal

        val rawOk = try {
            ImageCapture.getImageCaptureCapabilities(base.filter(p.availableCameraInfos).first())
                .supportedOutputFormats.contains(ImageCapture.OUTPUT_FORMAT_RAW)
        } catch (e: Exception) { false }
        if (raw && !(rawOk && plain)) {
            raw = false
            Toast.makeText(this, "RAW no disponible en este modo/teléfono", Toast.LENGTH_SHORT).show()
        }
        if (manual && !plain) manual = false

        val selector = if (plain) base else ext!!.getExtensionEnabledCameraSelector(base, mode)
        val pvB = Preview.Builder()
        val capB = ImageCapture.Builder().setCaptureMode(ImageCapture.CAPTURE_MODE_MAXIMIZE_QUALITY)
        if (raw) capB.setOutputFormat(ImageCapture.OUTPUT_FORMAT_RAW)
        if (manual) {
            manualOpts(Camera2Interop.Extender(pvB))
            manualOpts(Camera2Interop.Extender(capB))
        }
        val pv = pvB.build().also { it.setSurfaceProvider(preview.surfaceProvider) }
        capture = capB.build()
        p.unbindAll()
        camera = p.bindToLifecycle(this, selector, pv, capture)

        // Rango real de ISO del sensor
        try {
            Camera2CameraInfo.from(camera!!.cameraInfo)
                .getCameraCharacteristic(CameraCharacteristics.SENSOR_INFO_SENSITIVITY_RANGE)
                ?.let { isoMin = it.lower; isoMax = it.upper }
        } catch (_: Exception) {}

        // Compensación de exposición (EV)
        val r = camera!!.cameraInfo.exposureState.exposureCompensationRange
        evLower = r.lower
        evSeek.max = r.upper - r.lower
        evSeek.progress = -r.lower
        evSeek.visibility = if (!manual && r.upper > r.lower) View.VISIBLE else View.GONE

        manualBox.visibility = if (manual) View.VISIBLE else View.GONE
        btnMode.text = names[mode]
        btnRaw.text = "RAW: " + if (raw) "sí" else "no"
        btnManual.text = "Manual: " + if (manual) "sí" else "no"
        updateInfo()
    }

    private fun updateInfo() {
        tvInfo.text = if (manual) "ISO ${currentIso()}  •  1/${shutters[shSeek.progress]} s"
        else "Exposición (EV) — toca la imagen para enfocar"
    }

    private fun shoot() {
        val c = capture ?: return
        val stamp = SimpleDateFormat("yyyyMMdd_HHmmss", Locale.US).format(System.currentTimeMillis())
        val values = ContentValues().apply {
            if (raw) {
                put(MediaStore.MediaColumns.DISPLAY_NAME, "ProCam_$stamp.dng")
                put(MediaStore.MediaColumns.MIME_TYPE, "image/x-adobe-dng")
            } else {
                put(MediaStore.MediaColumns.DISPLAY_NAME, "ProCam_$stamp")
                put(MediaStore.MediaColumns.MIME_TYPE, "image/jpeg")
            }
            put(MediaStore.MediaColumns.RELATIVE_PATH, "Pictures/ProCam")
        }
        val opts = ImageCapture.OutputFileOptions.Builder(
            contentResolver, MediaStore.Images.Media.EXTERNAL_CONTENT_URI, values
        ).build()
        c.takePicture(opts, ContextCompat.getMainExecutor(this),
            object : ImageCapture.OnImageSavedCallback {
                override fun onImageSaved(r: ImageCapture.OutputFileResults) {
                    Toast.makeText(this@MainActivity, "Foto guardada", Toast.LENGTH_SHORT).show()
                }
                override fun onError(e: ImageCaptureException) {
                    Toast.makeText(this@MainActivity, "Error: ${e.message}", Toast.LENGTH_LONG).show()
                }
            })
    }
}
